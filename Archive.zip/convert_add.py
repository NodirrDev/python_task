def convert_add(arr):
    sum = 0
    for i in arr:
        sum += int(i)
    
    return sum




        
